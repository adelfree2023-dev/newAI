import { useState } from "react"
import { TemplateCard } from "@/components/common/TemplateCard"
import { motion } from "framer-motion"

const allTemplates = [
    { id: "1", name: "Apex Fashion", category: "Fashion" },
    { id: "2", name: "Quantum Tech", category: "Electronics" },
    { id: "3", name: "Organic Food", category: "Food" },
    { id: "4", name: "Vapor Minimal", category: "General" },
    { id: "5", name: "Premium Luxe", category: "Fashion" },
    { id: "6", name: "Titan Sports", category: "Sports" }
]

export const Templates = ({ isAr }: { isAr: boolean }) => {
    const [selected, setSelected] = useState<string | null>(null)

    return (
        <section className="py-32 bg-background-light dark:bg-background-dark overflow-hidden relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    className="text-center mb-20"
                >
                    <h2 className="text-4xl md:text-6xl font-black mb-6 tracking-tight">
                        {isAr ? 'اختر قالبك المثالي' : 'Choose Your Perfect Template'}
                    </h2>
                    <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                        {isAr ? 'تصفح مجموعتنا من القوالب المصممة احترافياً' : 'Browse our collection of professionally designed templates'}
                    </p>
                </motion.div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    {allTemplates.map((template) => (
                        <TemplateCard
                            key={template.id}
                            {...template}
                            image=""
                            onSelect={setSelected}
                            isAr={isAr}
                        />
                    ))}
                </div>
            </div>
        </section>
    )
}
