import { useState } from "react"
import { Navbar } from "./components/layout/Navbar"
import { Hero } from "./components/sections/Hero"
import { Features } from "./components/sections/Features"
import { Templates } from "./components/sections/Templates"
import { OnboardingModal } from "./components/sections/OnboardingModal"
import { SuccessState } from "./components/sections/SuccessState"
import { Footer } from "./components/layout/Footer"

import { useRTL } from "./hooks/useRTL"
import { useTheme } from "./hooks/useTheme"

function App() {
    const [lang, setLang] = useState<'ar' | 'en'>('ar')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [showSuccess, setShowSuccess] = useState(false)

    const isAr = lang === 'ar'

    useRTL(isAr)
    useTheme()

    const toggleLang = () => setLang(prev => prev === 'ar' ? 'en' : 'ar')


    const handleOnboardingComplete = (data: any) => {
        console.log("Onboarding complete:", data)
        setShowSuccess(true)
    }

    if (showSuccess) {
        return <SuccessState isAr={isAr} />
    }

    return (
        <div className={`min-h-screen ${isAr ? 'font-arabic' : 'font-sans'} bg-background-light dark:bg-background-dark transition-all duration-500`}>
            <Navbar isAr={isAr} onToggleLang={toggleLang} />

            <main>
                <Hero isAr={isAr} onGetStarted={() => setIsModalOpen(true)} />
                <Features isAr={isAr} />
                <Templates isAr={isAr} />
            </main>

            <OnboardingModal
                isAr={isAr}
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onComplete={handleOnboardingComplete}
            />

            <Footer isAr={isAr} />
        </div>
    )
}

export default App
